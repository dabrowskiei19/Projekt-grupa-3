Zadanie:
1 część zadania (NODEJS)
Pobrać dane z pliku JSON znajdującego się na serwerze imiki/cf i dodać te dane do bazy danych. 
Pobrać:
- czujnik temperatury1 (sesner1)
- czujnik temperatury2 (sesner2)
- czujnik temperatury3 (sesner3)
- czujnik temperatury4 (sesner4)
- czujnik wilgotności (HUMIDITYANDTEMPSENSOR)
- czujnik temperatury
Zapis co 1 minutę 
najepiej użyć biblioteki FOREVER (https://www.npmjs.com/package/forever)
2 część zadania (NODEJS)
Po wpisaniu danego url skrypt pobiera dane z bazy danych i zwraca je w postaci pliku JSON.
- czujnik temperatury1 (sesner1)
- znacznik czasowy  (sesner1)
- czujnik temperatury2 (sesner2)
- znacznik czasowy  (sesner2)
- czujnik temperatury3 (sesner3)
- znacznik czasowy  (sesner3)
- czujnik temperatury4 (sesner4)
- znacznik czasowy  (sesner4)
- czujnik wilgotności (HUMIDITYANDTEMPSENSOR)
- znacznik czasowy  (HUMIDITYANDTEMPSENSOR)
- czujnik temperatury
- znacznik czasowy
3 część zadania (WEB) 
Pobranie danych z serwera za pomocą url i wyświetalnie ich w tabeli.
Wykożystuje bootstramp do wizualizacji danych
4 część zadania (WEB https://www.chartjs.org/) 
Wizualizacja danych z tabeli w postaci wykresów 
