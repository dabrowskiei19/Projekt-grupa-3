SLECE * dd; 
